/**
 * AI-Driven Health Journal - Route Configuration
 * 
 * Complete health tracking application with 10 screens:
 * 1. Landing Page - Marketing page with features, testimonials
 * 2. Sign Up - User registration with form validation
 * 3. Login - User authentication with social login options
 * 4. Dashboard - Main health overview with metrics and charts
 * 5. Add Health Data - Form to log daily health metrics
 * 6. Analytics - Visual charts and health trend analysis
 * 7. AI Insights - AI-powered recommendations and health tips
 * 8. Goals - Goal tracking with progress monitoring
 * 9. Settings - Profile and notification preferences
 * 10. Reports - Health reports and emergency contacts
 */

import { createBrowserRouter } from "react-router";
import Landing from "./pages/Landing";
import SignUp from "./pages/SignUp";
import Login from "./pages/Login";
import Dashboard from "./pages/Dashboard";
import AddHealthData from "./pages/AddHealthData";
import Analytics from "./pages/Analytics";
import AIInsights from "./pages/AIInsights";
import Goals from "./pages/Goals";
import Settings from "./pages/Settings";
import Reports from "./pages/Reports";

export const router = createBrowserRouter([
  {
    path: "/",
    Component: Landing,
  },
  {
    path: "/signup",
    Component: SignUp,
  },
  {
    path: "/login",
    Component: Login,
  },
  {
    path: "/dashboard",
    Component: Dashboard,
  },
  {
    path: "/add-health-data",
    Component: AddHealthData,
  },
  {
    path: "/analytics",
    Component: Analytics,
  },
  {
    path: "/ai-insights",
    Component: AIInsights,
  },
  {
    path: "/goals",
    Component: Goals,
  },
  {
    path: "/settings",
    Component: Settings,
  },
  {
    path: "/reports",
    Component: Reports,
  },
]);