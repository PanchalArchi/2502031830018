import { useState } from 'react';
import { DashboardSidebar } from '../components/DashboardSidebar';
import { Card } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Sparkles, AlertTriangle, Lightbulb, TrendingUp, Send, Heart } from 'lucide-react';

const recommendations = [
  {
    icon: TrendingUp,
    title: 'Increase Daily Steps',
    description: 'You are close to achieving your step goal! Just 568 more steps to reach 10,000.',
    priority: 'high',
    color: 'primary',
  },
  {
    icon: Heart,
    title: 'Hydration Reminder',
    description: 'Increase water intake by 1L daily. Your current average is 1.5L, aim for 2.5L.',
    priority: 'medium',
    color: 'accent',
  },
  {
    icon: Lightbulb,
    title: 'Sleep Consistency',
    description: 'Try maintaining a consistent sleep schedule. Going to bed at the same time helps improve sleep quality.',
    priority: 'medium',
    color: 'secondary',
  },
];

const riskAlerts = [
  {
    title: 'Sleep Pattern Declined',
    description: 'Your sleep pattern has decreased by 12% this week. This may affect your energy levels and productivity.',
    severity: 'warning',
  },
  {
    title: 'Blood Pressure Monitoring',
    description: 'Your last 3 readings show slightly elevated systolic pressure. Consider reducing sodium intake.',
    severity: 'info',
  },
];

const healthTips = [
  {
    icon: '🏃',
    title: 'Morning Exercise',
    tip: 'Start your day with a 10-minute walk. Morning exercise can boost your metabolism for the entire day.',
  },
  {
    icon: '🥗',
    title: 'Balanced Nutrition',
    tip: 'Include more leafy greens in your diet. They are rich in vitamins and low in calories.',
  },
  {
    icon: '💧',
    title: 'Stay Hydrated',
    tip: 'Drink a glass of water first thing in the morning to kickstart your metabolism.',
  },
  {
    icon: '😴',
    title: 'Quality Sleep',
    tip: 'Avoid screens 1 hour before bedtime. Blue light can disrupt your natural sleep cycle.',
  },
];

const exampleQuestions = [
  'How can I improve my sleep quality?',
  'What should be my daily calorie intake?',
  'Tips for reducing stress?',
  'How to maintain healthy blood pressure?',
];

export default function AIInsights() {
  const [question, setQuestion] = useState('');
  const [conversation, setConversation] = useState<Array<{ type: 'user' | 'ai'; message: string }>>([]);

  const handleAskAI = (e: React.FormEvent) => {
    e.preventDefault();
    if (!question.trim()) return;

    const userMessage = question;
    setConversation([...conversation, { type: 'user', message: userMessage }]);
    
    // Simulate AI response
    setTimeout(() => {
      setConversation(prev => [
        ...prev,
        {
          type: 'ai',
          message: `Based on your health data, here's my recommendation for "${userMessage}": Maintain a consistent routine, monitor your metrics regularly, and consult with healthcare professionals for personalized advice. Your current health score is 92/100, which is excellent!`,
        },
      ]);
    }, 1000);

    setQuestion('');
  };

  return (
    <div className="flex min-h-screen bg-background">
      <DashboardSidebar />
      
      <div className="flex-1 overflow-auto">
        <div className="p-8">
          {/* Header */}
          <div className="mb-8">
            <div className="flex items-center gap-3 mb-2">
              <div className="w-10 h-10 bg-gradient-to-br from-primary to-accent rounded-xl flex items-center justify-center">
                <Sparkles className="w-6 h-6 text-white" />
              </div>
              <h1 className="text-3xl font-bold text-foreground">AI Health Insights</h1>
            </div>
            <p className="text-muted-foreground">Personalized recommendations powered by artificial intelligence</p>
          </div>

          {/* AI Recommendations */}
          <div className="mb-8">
            <h2 className="text-xl font-semibold text-foreground mb-4">AI Recommendations</h2>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {recommendations.map((rec, index) => {
                const Icon = rec.icon;
                return (
                  <Card key={index} className="p-6 hover:shadow-lg transition-shadow">
                    <div className={`w-12 h-12 bg-${rec.color}/10 rounded-xl flex items-center justify-center mb-4`}>
                      <Icon className={`w-6 h-6 text-${rec.color}`} style={{ 
                        color: rec.color === 'primary' ? '#2F80ED' : rec.color === 'secondary' ? '#27AE60' : '#56CCF2' 
                      }} />
                    </div>
                    <h3 className="font-semibold text-foreground mb-2">{rec.title}</h3>
                    <p className="text-sm text-muted-foreground mb-3">{rec.description}</p>
                    <div className="inline-flex px-2 py-1 bg-accent/10 text-accent text-xs font-medium rounded">
                      {rec.priority === 'high' ? 'High Priority' : 'Medium Priority'}
                    </div>
                  </Card>
                );
              })}
            </div>
          </div>

          {/* Risk Alerts */}
          <div className="mb-8">
            <h2 className="text-xl font-semibold text-foreground mb-4">Health Alerts</h2>
            <div className="space-y-4">
              {riskAlerts.map((alert, index) => (
                <Card key={index} className={`p-6 border-l-4 ${
                  alert.severity === 'warning' ? 'border-l-yellow-500 bg-yellow-50/50' : 'border-l-accent bg-accent/5'
                }`}>
                  <div className="flex items-start gap-4">
                    <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${
                      alert.severity === 'warning' ? 'bg-yellow-500/10' : 'bg-accent/10'
                    }`}>
                      <AlertTriangle className={`w-5 h-5 ${
                        alert.severity === 'warning' ? 'text-yellow-500' : 'text-accent'
                      }`} />
                    </div>
                    <div className="flex-1">
                      <h3 className="font-semibold text-foreground mb-1">{alert.title}</h3>
                      <p className="text-sm text-muted-foreground">{alert.description}</p>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          </div>

          {/* Smart Health Tips */}
          <div className="mb-8">
            <h2 className="text-xl font-semibold text-foreground mb-4">Smart Health Tips</h2>
            <div className="grid md:grid-cols-2 gap-4">
              {healthTips.map((tip, index) => (
                <Card key={index} className="p-5 hover:shadow-lg transition-shadow">
                  <div className="flex items-start gap-4">
                    <div className="text-3xl">{tip.icon}</div>
                    <div className="flex-1">
                      <h4 className="font-semibold text-foreground mb-1">{tip.title}</h4>
                      <p className="text-sm text-muted-foreground">{tip.tip}</p>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          </div>

          {/* Ask AI Section */}
          <Card className="p-6">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 bg-gradient-to-br from-primary to-accent rounded-xl flex items-center justify-center">
                <Sparkles className="w-5 h-5 text-white" />
              </div>
              <div>
                <h2 className="text-xl font-semibold text-foreground">Ask AI Assistant</h2>
                <p className="text-sm text-muted-foreground">Get personalized health advice</p>
              </div>
            </div>

            {/* Conversation Area */}
            {conversation.length > 0 && (
              <div className="mb-6 space-y-4 max-h-96 overflow-y-auto">
                {conversation.map((msg, index) => (
                  <div key={index} className={`flex ${msg.type === 'user' ? 'justify-end' : 'justify-start'}`}>
                    <div className={`max-w-[80%] p-4 rounded-xl ${
                      msg.type === 'user'
                        ? 'bg-primary text-white'
                        : 'bg-accent/10 text-foreground'
                    }`}>
                      <p className="text-sm">{msg.message}</p>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {/* Example Questions */}
            {conversation.length === 0 && (
              <div className="mb-6">
                <p className="text-sm text-muted-foreground mb-3">Try asking:</p>
                <div className="flex flex-wrap gap-2">
                  {exampleQuestions.map((q, index) => (
                    <button
                      key={index}
                      onClick={() => setQuestion(q)}
                      className="px-3 py-2 bg-accent/10 hover:bg-accent/20 text-sm text-foreground rounded-lg transition-colors"
                    >
                      {q}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Input Form */}
            <form onSubmit={handleAskAI} className="flex gap-3">
              <Input
                value={question}
                onChange={(e) => setQuestion(e.target.value)}
                placeholder="Ask me anything about your health..."
                className="flex-1"
              />
              <Button type="submit" className="bg-primary hover:bg-primary/90">
                <Send className="w-5 h-5" />
              </Button>
            </form>

            <p className="text-xs text-muted-foreground mt-3">
              💡 AI Assistant provides general health information. Always consult healthcare professionals for medical advice.
            </p>
          </Card>
        </div>
      </div>
    </div>
  );
}
