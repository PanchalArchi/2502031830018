import { DashboardSidebar } from '../components/DashboardSidebar';
import { Card } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { TrendingUp, TrendingDown, Calendar } from 'lucide-react';
import {
  LineChart,
  Line,
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from 'recharts';

const weightData = [
  { date: 'Jan 1', weight: 78.5 },
  { date: 'Jan 8', weight: 77.8 },
  { date: 'Jan 15', weight: 77.2 },
  { date: 'Jan 22', weight: 76.5 },
  { date: 'Jan 29', weight: 76.0 },
  { date: 'Feb 5', weight: 75.5 },
  { date: 'Feb 12', weight: 75.0 },
];

const activityData = [
  { day: 'Mon', steps: 7200, calories: 320 },
  { day: 'Tue', steps: 8500, calories: 380 },
  { day: 'Wed', steps: 6800, calories: 290 },
  { day: 'Thu', steps: 9200, calories: 420 },
  { day: 'Fri', steps: 8900, calories: 400 },
  { day: 'Sat', steps: 11500, calories: 520 },
  { day: 'Sun', steps: 8432, calories: 385 },
];

const nutritionData = [
  { name: 'Protein', value: 30, color: '#2F80ED' },
  { name: 'Carbs', value: 45, color: '#27AE60' },
  { name: 'Fats', value: 20, color: '#56CCF2' },
  { name: 'Other', value: 5, color: '#9B59B6' },
];

const monthlyComparison = [
  { metric: 'Steps', current: 8432, previous: 7521, change: 12 },
  { metric: 'Sleep', current: 7.5, previous: 8.2, change: -9 },
  { metric: 'Water', current: 6, previous: 5, change: 20 },
  { metric: 'Calories', current: 385, previous: 356, change: 8 },
];

export default function Analytics() {
  return (
    <div className="flex min-h-screen bg-background">
      <DashboardSidebar />
      
      <div className="flex-1 overflow-auto">
        <div className="p-8">
          {/* Header */}
          <div className="mb-8 flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-foreground mb-2">Health Analytics</h1>
              <p className="text-muted-foreground">Visualize your health trends and progress</p>
            </div>
            <Button variant="outline" className="gap-2">
              <Calendar className="w-4 h-4" />
              Last 30 Days
            </Button>
          </div>

          {/* Monthly Comparison Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            {monthlyComparison.map((item) => (
              <Card key={item.metric} className="p-6">
                <div className="text-sm text-muted-foreground mb-2">{item.metric}</div>
                <div className="flex items-end justify-between mb-3">
                  <div className="text-3xl font-bold text-foreground">{item.current}</div>
                  <div className={`flex items-center gap-1 text-sm font-medium ${
                    item.change > 0 ? 'text-secondary' : 'text-destructive'
                  }`}>
                    {item.change > 0 ? (
                      <TrendingUp className="w-4 h-4" />
                    ) : (
                      <TrendingDown className="w-4 h-4" />
                    )}
                    <span>{Math.abs(item.change)}%</span>
                  </div>
                </div>
                <div className="text-xs text-muted-foreground">
                  Previous: {item.previous}
                </div>
              </Card>
            ))}
          </div>

          {/* Charts Row 1 */}
          <div className="grid lg:grid-cols-2 gap-6 mb-6">
            {/* Weight Progress */}
            <Card className="p-6">
              <div className="flex items-center justify-between mb-6">
                <div>
                  <h3 className="text-lg font-semibold text-foreground">Weight Progress</h3>
                  <p className="text-sm text-muted-foreground">6-week trend</p>
                </div>
                <div className="text-right">
                  <div className="text-2xl font-bold text-foreground">-3.5kg</div>
                  <div className="text-sm text-secondary flex items-center justify-end gap-1">
                    <TrendingDown className="w-4 h-4" />
                    <span>4.5% decrease</span>
                  </div>
                </div>
              </div>
              <ResponsiveContainer width="100%" height={250}>
                <LineChart data={weightData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#E5E7EB" />
                  <XAxis dataKey="date" stroke="#6B7280" style={{ fontSize: '12px' }} />
                  <YAxis stroke="#6B7280" style={{ fontSize: '12px' }} domain={[74, 79]} />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: '#fff',
                      border: '1px solid #E5E7EB',
                      borderRadius: '8px',
                    }}
                  />
                  <Line
                    type="monotone"
                    dataKey="weight"
                    stroke="#2F80ED"
                    strokeWidth={3}
                    dot={{ fill: '#2F80ED', r: 5 }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </Card>

            {/* Weekly Activity */}
            <Card className="p-6">
              <div className="flex items-center justify-between mb-6">
                <div>
                  <h3 className="text-lg font-semibold text-foreground">Weekly Activity</h3>
                  <p className="text-sm text-muted-foreground">Steps vs Calories</p>
                </div>
              </div>
              <ResponsiveContainer width="100%" height={250}>
                <BarChart data={activityData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#E5E7EB" />
                  <XAxis dataKey="day" stroke="#6B7280" style={{ fontSize: '12px' }} />
                  <YAxis stroke="#6B7280" style={{ fontSize: '12px' }} />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: '#fff',
                      border: '1px solid #E5E7EB',
                      borderRadius: '8px',
                    }}
                  />
                  <Legend />
                  <Bar dataKey="steps" fill="#2F80ED" radius={[8, 8, 0, 0]} />
                  <Bar dataKey="calories" fill="#27AE60" radius={[8, 8, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </Card>
          </div>

          {/* Charts Row 2 */}
          <div className="grid lg:grid-cols-3 gap-6">
            {/* Nutrition Distribution */}
            <Card className="p-6 lg:col-span-1">
              <h3 className="text-lg font-semibold text-foreground mb-2">Nutrition Distribution</h3>
              <p className="text-sm text-muted-foreground mb-6">Average daily intake</p>
              <ResponsiveContainer width="100%" height={220}>
                <PieChart>
                  <Pie
                    data={nutritionData}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                    outerRadius={80}
                    fill="#8884d8"
                    dataKey="value"
                  >
                    {nutritionData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            </Card>

            {/* Health Insights Summary */}
            <Card className="p-6 lg:col-span-2">
              <h3 className="text-lg font-semibold text-foreground mb-4">Key Insights</h3>
              <div className="space-y-4">
                <div className="flex items-start gap-3 p-4 bg-secondary/5 rounded-xl">
                  <div className="w-10 h-10 bg-secondary/10 rounded-lg flex items-center justify-center flex-shrink-0">
                    <TrendingUp className="w-5 h-5 text-secondary" />
                  </div>
                  <div className="flex-1">
                    <h4 className="font-semibold text-foreground mb-1">Excellent Progress!</h4>
                    <p className="text-sm text-muted-foreground">
                      Your step count has increased by 12% this week. You're exceeding your daily goal 
                      by an average of 500 steps.
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-3 p-4 bg-yellow-500/5 rounded-xl">
                  <div className="w-10 h-10 bg-yellow-500/10 rounded-lg flex items-center justify-center flex-shrink-0">
                    <TrendingDown className="w-5 h-5 text-yellow-500" />
                  </div>
                  <div className="flex-1">
                    <h4 className="font-semibold text-foreground mb-1">Sleep Attention Needed</h4>
                    <p className="text-sm text-muted-foreground">
                      Your sleep duration decreased by 9% compared to last month. Try to maintain 
                      consistent sleep schedules.
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-3 p-4 bg-accent/5 rounded-xl">
                  <div className="w-10 h-10 bg-accent/10 rounded-lg flex items-center justify-center flex-shrink-0">
                    <TrendingUp className="w-5 h-5 text-accent" />
                  </div>
                  <div className="flex-1">
                    <h4 className="font-semibold text-foreground mb-1">Hydration Improving</h4>
                    <p className="text-sm text-muted-foreground">
                      Water intake increased by 20%. Keep up this excellent habit for optimal health.
                    </p>
                  </div>
                </div>
              </div>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
