import { DashboardSidebar } from '../components/DashboardSidebar';
import { Card } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { Separator } from '../components/ui/separator';
import { FileText, Download, Share2, UserCheck, Calendar, TrendingUp, Heart, Activity, AlertCircle, Phone } from 'lucide-react';
import { toast } from 'sonner';

const healthHistory = [
  {
    date: '2026-02-20',
    type: 'Health Check',
    description: 'Regular health data logged - All metrics normal',
    status: 'success',
  },
  {
    date: '2026-02-15',
    type: 'Goal Achieved',
    description: 'Completed 7-day streak goal',
    status: 'success',
  },
  {
    date: '2026-02-10',
    type: 'Health Alert',
    description: 'Elevated blood pressure detected',
    status: 'warning',
  },
  {
    date: '2026-02-05',
    type: 'Milestone',
    description: 'Reached 10,000 steps for 5 consecutive days',
    status: 'success',
  },
  {
    date: '2026-02-01',
    type: 'Health Check',
    description: 'Monthly health assessment completed',
    status: 'success',
  },
];

export default function Reports() {
  const handleDownloadReport = () => {
    toast.success('Health report downloaded successfully!');
  };

  const handleShareReport = () => {
    toast.success('Share link copied to clipboard!');
  };

  return (
    <div className="flex min-h-screen bg-background">
      <DashboardSidebar />
      
      <div className="flex-1 overflow-auto">
        <div className="p-8">
          {/* Header */}
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-foreground mb-2">Reports & Emergency</h1>
            <p className="text-muted-foreground">Access your health reports and emergency information</p>
          </div>

          <div className="grid lg:grid-cols-3 gap-6 mb-8">
            {/* Health Report Summary */}
            <Card className="p-6 lg:col-span-2">
              <div className="flex items-center justify-between mb-6">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-primary/10 rounded-xl flex items-center justify-center">
                    <FileText className="w-5 h-5 text-primary" />
                  </div>
                  <div>
                    <h2 className="text-xl font-semibold text-foreground">Health Report Summary</h2>
                    <p className="text-sm text-muted-foreground">Your comprehensive health overview</p>
                  </div>
                </div>
                <Button onClick={handleDownloadReport} className="bg-primary hover:bg-primary/90">
                  <Download className="w-4 h-4 mr-2" />
                  Download PDF
                </Button>
              </div>

              <div className="space-y-6">
                {/* Quick Stats */}
                <div className="grid grid-cols-3 gap-4">
                  <div className="p-4 bg-primary/5 rounded-xl">
                    <div className="flex items-center gap-2 mb-2">
                      <Activity className="w-4 h-4 text-primary" />
                      <span className="text-sm text-muted-foreground">Avg Steps</span>
                    </div>
                    <div className="text-2xl font-bold text-foreground">8,432</div>
                    <div className="text-xs text-muted-foreground mt-1">Last 30 days</div>
                  </div>

                  <div className="p-4 bg-secondary/5 rounded-xl">
                    <div className="flex items-center gap-2 mb-2">
                      <Heart className="w-4 h-4 text-secondary" />
                      <span className="text-sm text-muted-foreground">Health Score</span>
                    </div>
                    <div className="text-2xl font-bold text-foreground">92/100</div>
                    <div className="text-xs text-muted-foreground mt-1">Excellent</div>
                  </div>

                  <div className="p-4 bg-accent/5 rounded-xl">
                    <div className="flex items-center gap-2 mb-2">
                      <TrendingUp className="w-4 h-4 text-accent" />
                      <span className="text-sm text-muted-foreground">Weight Change</span>
                    </div>
                    <div className="text-2xl font-bold text-foreground">-3.5kg</div>
                    <div className="text-xs text-muted-foreground mt-1">Last 6 weeks</div>
                  </div>
                </div>

                <Separator />

                {/* Report Details */}
                <div className="space-y-4">
                  <div>
                    <h3 className="font-semibold text-foreground mb-2">Report Period</h3>
                    <div className="flex items-center gap-2 text-sm text-muted-foreground">
                      <Calendar className="w-4 h-4" />
                      <span>January 1, 2026 - February 26, 2026</span>
                    </div>
                  </div>

                  <div>
                    <h3 className="font-semibold text-foreground mb-2">Key Highlights</h3>
                    <ul className="space-y-2 text-sm text-muted-foreground">
                      <li className="flex items-start gap-2">
                        <span className="text-secondary">✓</span>
                        <span>Maintained consistent exercise routine with 84% daily step goal achievement</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="text-secondary">✓</span>
                        <span>Weight loss progress on track - Lost 3.5kg towards 5kg goal</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="text-secondary">✓</span>
                        <span>Improved hydration levels by 20% compared to previous month</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="text-yellow-500">!</span>
                        <span>Sleep quality decreased by 9% - needs attention</span>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
            </Card>

            {/* Quick Actions */}
            <Card className="p-6">
              <h3 className="font-semibold text-foreground mb-4">Quick Actions</h3>
              <div className="space-y-3">
                <Button onClick={handleDownloadReport} variant="outline" className="w-full justify-start">
                  <Download className="w-4 h-4 mr-2" />
                  Download Report (PDF)
                </Button>
                <Button onClick={handleShareReport} variant="outline" className="w-full justify-start">
                  <Share2 className="w-4 h-4 mr-2" />
                  Share Report
                </Button>
                <Button variant="outline" className="w-full justify-start">
                  <UserCheck className="w-4 h-4 mr-2" />
                  Share with Doctor
                </Button>
                <Separator />
                <div className="pt-2">
                  <Label className="text-sm text-muted-foreground mb-2 block">Custom Date Range</Label>
                  <div className="space-y-2">
                    <Input type="date" placeholder="Start Date" />
                    <Input type="date" placeholder="End Date" />
                    <Button className="w-full bg-primary hover:bg-primary/90">
                      Generate Report
                    </Button>
                  </div>
                </div>
              </div>
            </Card>
          </div>

          {/* Emergency Contact Information */}
          <Card className="p-6 mb-8 bg-destructive/5 border-destructive/20">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 bg-destructive/10 rounded-xl flex items-center justify-center">
                <AlertCircle className="w-5 h-5 text-destructive" />
              </div>
              <div>
                <h2 className="text-xl font-semibold text-foreground">Emergency Contact Information</h2>
                <p className="text-sm text-muted-foreground">Important contacts in case of medical emergency</p>
              </div>
            </div>

            <div className="grid md:grid-cols-2 gap-6">
              <div className="space-y-4">
                <div>
                  <Label htmlFor="emergencyName">Emergency Contact Name</Label>
                  <Input id="emergencyName" placeholder="Jane Doe" className="mt-2" />
                </div>
                <div>
                  <Label htmlFor="emergencyPhone">Emergency Contact Phone</Label>
                  <Input id="emergencyPhone" type="tel" placeholder="+1 (555) 123-4567" className="mt-2" />
                </div>
                <div>
                  <Label htmlFor="relationship">Relationship</Label>
                  <Input id="relationship" placeholder="Spouse" className="mt-2" />
                </div>
              </div>

              <div className="space-y-4">
                <div>
                  <Label htmlFor="doctorName">Primary Doctor</Label>
                  <Input id="doctorName" placeholder="Dr. Smith" className="mt-2" />
                </div>
                <div>
                  <Label htmlFor="doctorPhone">Doctor's Phone</Label>
                  <Input id="doctorPhone" type="tel" placeholder="+1 (555) 987-6543" className="mt-2" />
                </div>
                <div>
                  <Label htmlFor="bloodType">Blood Type</Label>
                  <Input id="bloodType" placeholder="O+" className="mt-2" />
                </div>
              </div>
            </div>

            <div className="mt-4">
              <Label htmlFor="allergies">Known Allergies & Medical Conditions</Label>
              <Input id="allergies" placeholder="List any allergies or medical conditions..." className="mt-2" />
            </div>

            <Button className="mt-4 bg-destructive hover:bg-destructive/90">
              <Phone className="w-4 h-4 mr-2" />
              Save Emergency Info
            </Button>
          </Card>

          {/* Health History Timeline */}
          <Card className="p-6">
            <div className="flex items-center gap-3 mb-6">
              <div className="w-10 h-10 bg-accent/10 rounded-xl flex items-center justify-center">
                <Calendar className="w-5 h-5 text-accent" />
              </div>
              <div>
                <h2 className="text-xl font-semibold text-foreground">Health History Timeline</h2>
                <p className="text-sm text-muted-foreground">Your health journey over time</p>
              </div>
            </div>

            <div className="space-y-4">
              {healthHistory.map((event, index) => (
                <div key={index} className="flex gap-4">
                  <div className="flex flex-col items-center">
                    <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                      event.status === 'success' ? 'bg-secondary/10' :
                      event.status === 'warning' ? 'bg-yellow-500/10' :
                      'bg-accent/10'
                    }`}>
                      {event.status === 'success' ? (
                        <Heart className={`w-5 h-5 text-secondary`} />
                      ) : event.status === 'warning' ? (
                        <AlertCircle className={`w-5 h-5 text-yellow-500`} />
                      ) : (
                        <Activity className={`w-5 h-5 text-accent`} />
                      )}
                    </div>
                    {index < healthHistory.length - 1 && (
                      <div className="w-0.5 h-12 bg-gray-200 my-1"></div>
                    )}
                  </div>
                  <div className="flex-1 pb-8">
                    <div className="flex items-center justify-between mb-1">
                      <h4 className="font-semibold text-foreground">{event.type}</h4>
                      <span className="text-xs text-muted-foreground">{new Date(event.date).toLocaleDateString()}</span>
                    </div>
                    <p className="text-sm text-muted-foreground">{event.description}</p>
                  </div>
                </div>
              ))}
            </div>

            <Button variant="outline" className="w-full mt-4">
              View Full History
            </Button>
          </Card>

          {/* Doctor Access */}
          <Card className="p-6 mt-6 bg-primary/5 border-primary/20">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center">
                  <UserCheck className="w-6 h-6 text-primary" />
                </div>
                <div>
                  <h3 className="font-semibold text-foreground mb-1">Doctor Access Portal</h3>
                  <p className="text-sm text-muted-foreground">
                    Share your health data securely with your healthcare provider
                  </p>
                </div>
              </div>
              <Button className="bg-primary hover:bg-primary/90">
                Grant Access
              </Button>
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}
