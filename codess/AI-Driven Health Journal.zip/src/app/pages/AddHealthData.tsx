import { useState } from 'react';
import { useNavigate } from 'react-router';
import { DashboardSidebar } from '../components/DashboardSidebar';
import { Card } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { Save, Smile, Meh, Frown } from 'lucide-react';
import { toast } from 'sonner';

const moodEmojis = [
  { icon: Smile, label: 'Great', value: 'great', color: 'text-secondary' },
  { icon: Smile, label: 'Good', value: 'good', color: 'text-primary' },
  { icon: Meh, label: 'Okay', value: 'okay', color: 'text-accent' },
  { icon: Frown, label: 'Bad', value: 'bad', color: 'text-yellow-500' },
  { icon: Frown, label: 'Terrible', value: 'terrible', color: 'text-destructive' },
];

export default function AddHealthData() {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    date: new Date().toISOString().split('T')[0],
    weight: '',
    bloodPressureSystolic: '',
    bloodPressureDiastolic: '',
    bloodSugar: '',
    heartRate: '',
    mood: '',
    sleepHours: '',
    waterIntake: '',
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    toast.success('Health data saved successfully!');
    setTimeout(() => navigate('/dashboard'), 1500);
  };

  return (
    <div className="flex min-h-screen bg-background">
      <DashboardSidebar />
      
      <div className="flex-1 overflow-auto">
        <div className="p-8">
          {/* Header */}
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-foreground mb-2">Add Health Data</h1>
            <p className="text-muted-foreground">Log your daily health metrics and track your progress</p>
          </div>

          <Card className="p-8 max-w-3xl">
            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Date */}
              <div>
                <Label htmlFor="date">Date</Label>
                <Input
                  id="date"
                  type="date"
                  value={formData.date}
                  onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                  required
                  className="mt-2"
                />
              </div>

              {/* Vital Signs */}
              <div>
                <h3 className="text-lg font-semibold mb-4">Vital Signs</h3>
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="weight">Weight (kg)</Label>
                    <Input
                      id="weight"
                      type="number"
                      step="0.1"
                      placeholder="70.5"
                      value={formData.weight}
                      onChange={(e) => setFormData({ ...formData, weight: e.target.value })}
                      className="mt-2"
                    />
                  </div>

                  <div>
                    <Label htmlFor="heartRate">Heart Rate (bpm)</Label>
                    <Input
                      id="heartRate"
                      type="number"
                      placeholder="72"
                      value={formData.heartRate}
                      onChange={(e) => setFormData({ ...formData, heartRate: e.target.value })}
                      className="mt-2"
                    />
                  </div>

                  <div>
                    <Label>Blood Pressure (mmHg)</Label>
                    <div className="flex gap-2 mt-2">
                      <Input
                        type="number"
                        placeholder="120"
                        value={formData.bloodPressureSystolic}
                        onChange={(e) => setFormData({ ...formData, bloodPressureSystolic: e.target.value })}
                      />
                      <span className="flex items-center text-muted-foreground">/</span>
                      <Input
                        type="number"
                        placeholder="80"
                        value={formData.bloodPressureDiastolic}
                        onChange={(e) => setFormData({ ...formData, bloodPressureDiastolic: e.target.value })}
                      />
                    </div>
                  </div>

                  <div>
                    <Label htmlFor="bloodSugar">Blood Sugar (mg/dL)</Label>
                    <Input
                      id="bloodSugar"
                      type="number"
                      placeholder="95"
                      value={formData.bloodSugar}
                      onChange={(e) => setFormData({ ...formData, bloodSugar: e.target.value })}
                      className="mt-2"
                    />
                  </div>
                </div>
              </div>

              {/* Lifestyle */}
              <div>
                <h3 className="text-lg font-semibold mb-4">Lifestyle</h3>
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="sleepHours">Sleep Hours</Label>
                    <Input
                      id="sleepHours"
                      type="number"
                      step="0.5"
                      placeholder="7.5"
                      value={formData.sleepHours}
                      onChange={(e) => setFormData({ ...formData, sleepHours: e.target.value })}
                      className="mt-2"
                    />
                  </div>

                  <div>
                    <Label htmlFor="waterIntake">Water Intake (glasses)</Label>
                    <Input
                      id="waterIntake"
                      type="number"
                      placeholder="8"
                      value={formData.waterIntake}
                      onChange={(e) => setFormData({ ...formData, waterIntake: e.target.value })}
                      className="mt-2"
                    />
                  </div>
                </div>
              </div>

              {/* Mood */}
              <div>
                <Label className="mb-3 block">How are you feeling today?</Label>
                <div className="flex gap-3">
                  {moodEmojis.map((mood) => {
                    const Icon = mood.icon;
                    return (
                      <button
                        key={mood.value}
                        type="button"
                        onClick={() => setFormData({ ...formData, mood: mood.value })}
                        className={`flex-1 p-4 rounded-xl border-2 transition-all ${
                          formData.mood === mood.value
                            ? 'border-primary bg-primary/5'
                            : 'border-gray-200 hover:border-gray-300'
                        }`}
                      >
                        <Icon className={`w-8 h-8 mx-auto mb-2 ${mood.color}`} />
                        <div className="text-sm font-medium">{mood.label}</div>
                      </button>
                    );
                  })}
                </div>
              </div>

              <div className="flex gap-4 pt-4">
                <Button type="submit" className="bg-primary hover:bg-primary/90 flex-1">
                  <Save className="w-5 h-5 mr-2" />
                  Save Entry
                </Button>
                <Button type="button" variant="outline" onClick={() => navigate('/dashboard')}>
                  Cancel
                </Button>
              </div>
            </form>
          </Card>

          {/* Info Card */}
          <Card className="p-6 mt-6 max-w-3xl bg-accent/5 border-accent/20">
            <h4 className="font-semibold text-foreground mb-2">💡 Pro Tip</h4>
            <p className="text-sm text-muted-foreground">
              For the most accurate insights, try to log your health data at the same time each day. 
              Consistency helps our AI provide better personalized recommendations.
            </p>
          </Card>
        </div>
      </div>
    </div>
  );
}
