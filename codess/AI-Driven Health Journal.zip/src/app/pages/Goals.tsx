import { useState } from 'react';
import { DashboardSidebar } from '../components/DashboardSidebar';
import { Card } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Progress } from '../components/ui/progress';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '../components/ui/dialog';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select';
import { Target, Trophy, Flame, Plus, Calendar, TrendingUp } from 'lucide-react';

const goals = [
  {
    id: 1,
    icon: Target,
    title: 'Weight Loss Goal',
    description: 'Lose 5kg in 3 months',
    current: 75,
    target: 70,
    unit: 'kg',
    progress: 70,
    startDate: '2026-01-01',
    endDate: '2026-03-31',
    color: 'primary',
  },
  {
    id: 2,
    icon: Flame,
    title: 'Daily Steps Goal',
    description: 'Walk 10,000 steps daily',
    current: 8432,
    target: 10000,
    unit: 'steps',
    progress: 84,
    startDate: '2026-02-01',
    endDate: '2026-02-28',
    color: 'secondary',
  },
  {
    id: 3,
    icon: TrendingUp,
    title: 'Sleep Improvement',
    description: 'Achieve 8 hours of sleep',
    current: 7.5,
    target: 8,
    unit: 'hours',
    progress: 94,
    startDate: '2026-02-01',
    endDate: '2026-03-01',
    color: 'accent',
  },
];

const achievements = [
  { icon: '🏆', title: '7-Day Streak', description: 'Logged health data for 7 consecutive days' },
  { icon: '🎯', title: 'Goal Achiever', description: 'Completed your first health goal' },
  { icon: '💪', title: 'Step Master', description: 'Reached 10,000 steps in a day' },
  { icon: '⭐', title: 'Consistency King', description: 'Maintained health routine for 30 days' },
  { icon: '🌟', title: 'Health Champion', description: 'AI Health Score above 90 for a week' },
  { icon: '🔥', title: 'Fitness Warrior', description: 'Burned 500+ calories in a day' },
];

export default function Goals() {
  const [open, setOpen] = useState(false);
  const currentStreak = 12;

  return (
    <div className="flex min-h-screen bg-background">
      <DashboardSidebar />
      
      <div className="flex-1 overflow-auto">
        <div className="p-8">
          {/* Header */}
          <div className="mb-8 flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-foreground mb-2">Goals & Progress</h1>
              <p className="text-muted-foreground">Track your health goals and celebrate achievements</p>
            </div>
            <Dialog open={open} onOpenChange={setOpen}>
              <DialogTrigger asChild>
                <Button className="bg-primary hover:bg-primary/90">
                  <Plus className="w-5 h-5 mr-2" />
                  Set New Goal
                </Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-md">
                <DialogHeader>
                  <DialogTitle>Create New Goal</DialogTitle>
                </DialogHeader>
                <form className="space-y-4 mt-4">
                  <div>
                    <Label htmlFor="goalType">Goal Type</Label>
                    <Select>
                      <SelectTrigger className="mt-2">
                        <SelectValue placeholder="Select goal type" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="weight">Weight Loss/Gain</SelectItem>
                        <SelectItem value="steps">Daily Steps</SelectItem>
                        <SelectItem value="sleep">Sleep Improvement</SelectItem>
                        <SelectItem value="water">Water Intake</SelectItem>
                        <SelectItem value="calories">Calorie Burn</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="current">Current Value</Label>
                      <Input id="current" type="number" placeholder="75" className="mt-2" />
                    </div>
                    <div>
                      <Label htmlFor="target">Target Value</Label>
                      <Input id="target" type="number" placeholder="70" className="mt-2" />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="startDate">Start Date</Label>
                      <Input id="startDate" type="date" className="mt-2" />
                    </div>
                    <div>
                      <Label htmlFor="endDate">Target Date</Label>
                      <Input id="endDate" type="date" className="mt-2" />
                    </div>
                  </div>

                  <div className="flex gap-3 pt-4">
                    <Button type="submit" className="flex-1 bg-primary hover:bg-primary/90">
                      Create Goal
                    </Button>
                    <Button type="button" variant="outline" onClick={() => setOpen(false)}>
                      Cancel
                    </Button>
                  </div>
                </form>
              </DialogContent>
            </Dialog>
          </div>

          {/* Streak Tracker */}
          <Card className="p-6 mb-8 bg-gradient-to-r from-primary/5 to-accent/5 border-primary/20">
            <div className="flex items-center gap-6">
              <div className="w-20 h-20 bg-gradient-to-br from-primary to-accent rounded-2xl flex items-center justify-center flex-shrink-0">
                <Flame className="w-10 h-10 text-white" />
              </div>
              <div className="flex-1">
                <div className="flex items-baseline gap-2 mb-1">
                  <span className="text-4xl font-bold text-foreground">{currentStreak}</span>
                  <span className="text-xl text-muted-foreground">days</span>
                </div>
                <p className="text-sm text-muted-foreground">Current streak of logging health data</p>
              </div>
              <div className="text-right">
                <div className="text-sm text-muted-foreground mb-1">Best Streak</div>
                <div className="text-2xl font-bold text-primary">28 days</div>
              </div>
            </div>
          </Card>

          {/* Active Goals */}
          <div className="mb-8">
            <h2 className="text-xl font-semibold text-foreground mb-4">Active Goals</h2>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {goals.map((goal) => {
                const Icon = goal.icon;
                const colorClass = goal.color === 'primary' ? '#2F80ED' : goal.color === 'secondary' ? '#27AE60' : '#56CCF2';
                
                return (
                  <Card key={goal.id} className="p-6 hover:shadow-lg transition-shadow">
                    <div className="flex items-start justify-between mb-4">
                      <div className={`w-12 h-12 rounded-xl flex items-center justify-center`} style={{ backgroundColor: `${colorClass}15` }}>
                        <Icon className="w-6 h-6" style={{ color: colorClass }} />
                      </div>
                      <div className="text-right">
                        <div className="text-sm text-muted-foreground">Progress</div>
                        <div className="text-2xl font-bold text-foreground">{goal.progress}%</div>
                      </div>
                    </div>

                    <h3 className="font-semibold text-foreground mb-1">{goal.title}</h3>
                    <p className="text-sm text-muted-foreground mb-4">{goal.description}</p>

                    <div className="mb-3">
                      <div className="flex justify-between text-sm mb-2">
                        <span className="text-muted-foreground">Current: {goal.current} {goal.unit}</span>
                        <span className="text-muted-foreground">Target: {goal.target} {goal.unit}</span>
                      </div>
                      <Progress value={goal.progress} className="h-3" />
                    </div>

                    <div className="flex items-center gap-2 text-xs text-muted-foreground">
                      <Calendar className="w-3 h-3" />
                      <span>Ends on {new Date(goal.endDate).toLocaleDateString()}</span>
                    </div>
                  </Card>
                );
              })}
            </div>
          </div>

          {/* Achievement Badges */}
          <div>
            <div className="flex items-center justify-between mb-4">
              <div>
                <h2 className="text-xl font-semibold text-foreground">Achievement Badges</h2>
                <p className="text-sm text-muted-foreground">Your health milestones</p>
              </div>
              <div className="flex items-center gap-2 px-4 py-2 bg-accent/10 rounded-xl">
                <Trophy className="w-5 h-5 text-accent" />
                <span className="font-semibold text-foreground">{achievements.length} Badges Earned</span>
              </div>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
              {achievements.map((achievement, index) => (
                <Card key={index} className="p-4 text-center hover:shadow-lg transition-shadow cursor-pointer">
                  <div className="text-4xl mb-2">{achievement.icon}</div>
                  <h4 className="font-semibold text-sm text-foreground mb-1">{achievement.title}</h4>
                  <p className="text-xs text-muted-foreground">{achievement.description}</p>
                </Card>
              ))}
            </div>
          </div>

          {/* Motivational Card */}
          <Card className="p-6 mt-8 bg-gradient-to-r from-secondary/10 to-primary/10 border-primary/20">
            <div className="flex items-center gap-4">
              <div className="w-16 h-16 bg-white rounded-2xl flex items-center justify-center flex-shrink-0 shadow-lg">
                <Trophy className="w-8 h-8 text-primary" />
              </div>
              <div className="flex-1">
                <h3 className="font-semibold text-foreground mb-1">Keep Going! 💪</h3>
                <p className="text-sm text-muted-foreground">
                  You're making amazing progress! You're only 568 steps away from hitting your daily goal. 
                  Every step counts towards a healthier you!
                </p>
              </div>
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}
