import { DashboardSidebar } from '../components/DashboardSidebar';
import { Card } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Progress } from '../components/ui/progress';
import { Heart, Footprints, Flame, Moon, Droplets, TrendingUp, TrendingDown, AlertCircle, Plus } from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { Link } from 'react-router';

const weeklyData = [
  { day: 'Mon', steps: 7200, calories: 320 },
  { day: 'Tue', steps: 8500, calories: 380 },
  { day: 'Wed', steps: 6800, calories: 290 },
  { day: 'Thu', steps: 9200, calories: 420 },
  { day: 'Fri', steps: 8900, calories: 400 },
  { day: 'Sat', steps: 11500, calories: 520 },
  { day: 'Sun', steps: 8432, calories: 385 },
];

const notifications = [
  { type: 'success', message: 'Great job! You hit your step goal yesterday', time: '2h ago' },
  { type: 'warning', message: 'Your sleep pattern decreased by 12% this week', time: '5h ago' },
  { type: 'info', message: 'Time for your daily health check-in', time: '1d ago' },
];

export default function Dashboard() {
  return (
    <div className="flex min-h-screen bg-background">
      <DashboardSidebar />
      
      <div className="flex-1 overflow-auto">
        <div className="p-8">
          {/* Header */}
          <div className="mb-8 flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-foreground mb-2">Welcome back, John! 👋</h1>
              <p className="text-muted-foreground">Here's your health summary for today</p>
            </div>
            <Link to="/add-health-data">
              <Button className="bg-primary hover:bg-primary/90">
                <Plus className="w-5 h-5 mr-2" />
                Add Health Data
              </Button>
            </Link>
          </div>

          {/* Health Summary Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <Card className="p-6 hover:shadow-lg transition-shadow">
              <div className="flex items-start justify-between mb-4">
                <div className="w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center">
                  <Footprints className="w-6 h-6 text-primary" />
                </div>
                <div className="flex items-center gap-1 text-secondary">
                  <TrendingUp className="w-4 h-4" />
                  <span className="text-sm font-medium">+12%</span>
                </div>
              </div>
              <div className="text-3xl font-bold text-foreground mb-1">8,432</div>
              <div className="text-sm text-muted-foreground mb-3">Steps Today</div>
              <Progress value={84} className="h-2" />
              <div className="text-xs text-muted-foreground mt-2">84% of daily goal (10,000)</div>
            </Card>

            <Card className="p-6 hover:shadow-lg transition-shadow">
              <div className="flex items-start justify-between mb-4">
                <div className="w-12 h-12 bg-secondary/10 rounded-xl flex items-center justify-center">
                  <Flame className="w-6 h-6 text-secondary" />
                </div>
                <div className="flex items-center gap-1 text-secondary">
                  <TrendingUp className="w-4 h-4" />
                  <span className="text-sm font-medium">+8%</span>
                </div>
              </div>
              <div className="text-3xl font-bold text-foreground mb-1">385</div>
              <div className="text-sm text-muted-foreground mb-3">Calories Burned</div>
              <Progress value={77} className="h-2" />
              <div className="text-xs text-muted-foreground mt-2">77% of daily goal (500)</div>
            </Card>

            <Card className="p-6 hover:shadow-lg transition-shadow">
              <div className="flex items-start justify-between mb-4">
                <div className="w-12 h-12 bg-purple-500/10 rounded-xl flex items-center justify-center">
                  <Moon className="w-6 h-6 text-purple-500" />
                </div>
                <div className="flex items-center gap-1 text-destructive">
                  <TrendingDown className="w-4 h-4" />
                  <span className="text-sm font-medium">-5%</span>
                </div>
              </div>
              <div className="text-3xl font-bold text-foreground mb-1">7.5h</div>
              <div className="text-sm text-muted-foreground mb-3">Sleep Hours</div>
              <Progress value={94} className="h-2" />
              <div className="text-xs text-muted-foreground mt-2">94% of recommended (8h)</div>
            </Card>

            <Card className="p-6 hover:shadow-lg transition-shadow">
              <div className="flex items-start justify-between mb-4">
                <div className="w-12 h-12 bg-accent/10 rounded-xl flex items-center justify-center">
                  <Droplets className="w-6 h-6 text-accent" />
                </div>
                <div className="flex items-center gap-1 text-secondary">
                  <TrendingUp className="w-4 h-4" />
                  <span className="text-sm font-medium">+15%</span>
                </div>
              </div>
              <div className="text-3xl font-bold text-foreground mb-1">6/8</div>
              <div className="text-sm text-muted-foreground mb-3">Water Glasses</div>
              <Progress value={75} className="h-2" />
              <div className="text-xs text-muted-foreground mt-2">75% of daily goal (8 glasses)</div>
            </Card>
          </div>

          <div className="grid lg:grid-cols-3 gap-6 mb-8">
            {/* AI Health Score */}
            <Card className="p-6">
              <h3 className="text-lg font-semibold mb-4">AI Health Score</h3>
              <div className="flex items-center justify-center mb-4">
                <div className="relative w-40 h-40">
                  <svg className="transform -rotate-90 w-40 h-40">
                    <circle
                      cx="80"
                      cy="80"
                      r="70"
                      stroke="currentColor"
                      strokeWidth="12"
                      fill="transparent"
                      className="text-gray-200"
                    />
                    <circle
                      cx="80"
                      cy="80"
                      r="70"
                      stroke="currentColor"
                      strokeWidth="12"
                      fill="transparent"
                      strokeDasharray={`${2 * Math.PI * 70}`}
                      strokeDashoffset={`${2 * Math.PI * 70 * (1 - 0.92)}`}
                      className="text-primary"
                      strokeLinecap="round"
                    />
                  </svg>
                  <div className="absolute inset-0 flex items-center justify-center flex-col">
                    <div className="text-4xl font-bold text-foreground">92</div>
                    <div className="text-sm text-muted-foreground">out of 100</div>
                  </div>
                </div>
              </div>
              <div className="text-center">
                <div className="inline-flex px-3 py-1 bg-secondary/10 text-secondary rounded-full text-sm font-medium">
                  Excellent Health
                </div>
                <p className="text-sm text-muted-foreground mt-3">
                  Your overall health is looking great! Keep up the good work.
                </p>
              </div>
            </Card>

            {/* Weekly Overview Chart */}
            <Card className="p-6 lg:col-span-2">
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-lg font-semibold">Weekly Activity Overview</h3>
                <div className="flex items-center gap-4">
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 bg-primary rounded-full"></div>
                    <span className="text-sm text-muted-foreground">Steps</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 bg-secondary rounded-full"></div>
                    <span className="text-sm text-muted-foreground">Calories</span>
                  </div>
                </div>
              </div>
              <ResponsiveContainer width="100%" height={220}>
                <LineChart data={weeklyData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#E5E7EB" />
                  <XAxis dataKey="day" stroke="#6B7280" style={{ fontSize: '12px' }} />
                  <YAxis stroke="#6B7280" style={{ fontSize: '12px' }} />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: '#fff',
                      border: '1px solid #E5E7EB',
                      borderRadius: '8px',
                    }}
                  />
                  <Line type="monotone" dataKey="steps" stroke="#2F80ED" strokeWidth={3} dot={{ fill: '#2F80ED', r: 4 }} />
                  <Line type="monotone" dataKey="calories" stroke="#27AE60" strokeWidth={3} dot={{ fill: '#27AE60', r: 4 }} />
                </LineChart>
              </ResponsiveContainer>
            </Card>
          </div>

          {/* Notifications */}
          <Card className="p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold">Recent Notifications</h3>
              <Button variant="ghost" size="sm">View All</Button>
            </div>
            <div className="space-y-3">
              {notifications.map((notification, index) => (
                <div key={index} className="flex items-start gap-3 p-4 bg-accent/5 rounded-xl hover:bg-accent/10 transition-colors">
                  <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${
                    notification.type === 'success' ? 'bg-secondary/10' :
                    notification.type === 'warning' ? 'bg-yellow-500/10' :
                    'bg-accent/10'
                  }`}>
                    {notification.type === 'success' ? (
                      <Heart className={`w-5 h-5 text-secondary`} />
                    ) : notification.type === 'warning' ? (
                      <AlertCircle className={`w-5 h-5 text-yellow-500`} />
                    ) : (
                      <Heart className={`w-5 h-5 text-accent`} />
                    )}
                  </div>
                  <div className="flex-1">
                    <p className="text-sm text-foreground">{notification.message}</p>
                    <p className="text-xs text-muted-foreground mt-1">{notification.time}</p>
                  </div>
                </div>
              ))}
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}
