
  # AI-Driven Health Journal

  This is a code bundle for AI-Driven Health Journal. The original project is available at https://www.figma.com/design/ykGw0tXbmE6phA0cXy6XCo/AI-Driven-Health-Journal.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  